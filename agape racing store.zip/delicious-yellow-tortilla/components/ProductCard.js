import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function ProductCard({ item, isDark }) {
  return (
    <View style={[styles.card, isDark && styles.darkCard]}>

      <Text style={styles.image}>{item.image}</Text>

      <Text style={[styles.name, isDark && styles.darkText]}>
        {item.name}
      </Text>

      <Text style={styles.category}>
        {item.category}
      </Text>

      <View style={styles.footer}>
        <Text style={[styles.price, isDark && styles.darkText]}>
          Rp {item.price}
        </Text>

        <Text style={styles.rating}>
          {item.rating} ★
        </Text>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    margin: 6,
    padding: 12,
    borderRadius: 16,

    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },

  darkCard: {
    backgroundColor: "#1A1D24",
  },

  image: {
    fontSize: 26,
    marginBottom: 8,
  },

  name: {
    fontSize: 13,
    fontWeight: "600",
    color: "#111",
  },

  darkText: {
    color: "#fff",
  },

  category: {
    fontSize: 11,
    color: "#999",
    marginTop: 2,
  },

  footer: {
    marginTop: 10,
    flexDirection: "row",
    justifyContent: "space-between",
  },

  price: {
    fontSize: 12,
    color: "#333",
    fontWeight: "600",
  },

  rating: {
    fontSize: 12,
    color: "#777",
  },
});