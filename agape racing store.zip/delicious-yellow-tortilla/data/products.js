export const products = [
  { id: "1", name: "Turbo Garrett GTX3076R", category: "Turbo", price: 18000000, rating: 4.9, image: "💨" },
  { id: "2", name: "HKS Racing Blow Off Valve", category: "Turbo", price: 3500000, rating: 4.8, image: "🔊" },
  { id: "3", name: "Mishimoto Intercooler", category: "Cooling", price: 7500000, rating: 4.7, image: "❄️" },
  { id: "4", name: "Apexi Air Intake System", category: "Intake", price: 2500000, rating: 4.6, image: "🌪️" },
  { id: "5", name: "Greddy Turbo Timer", category: "Electronics", price: 1200000, rating: 4.5, image: "⏱️" },

  { id: "6", name: "Bride Racing Seat", category: "Interior", price: 6500000, rating: 4.9, image: "🪑" },
  { id: "7", name: "Sparco Steering Wheel", category: "Interior", price: 3200000, rating: 4.8, image: "🎮" },
  { id: "8", name: "Takata Racing Harness", category: "Safety", price: 2800000, rating: 4.7, image: "🛡️" },
  { id: "9", name: "Recaro Bucket Seat", category: "Interior", price: 8000000, rating: 4.9, image: "🪑" },
  { id: "10", name: "OMP Roll Cage Kit", category: "Safety", price: 15000000, rating: 4.8, image: "🔩" },

  { id: "11", name: "Nissan GTR RB26 Engine Swap", category: "Engine", price: 120000000, rating: 5.0, image: "🚗" },
  { id: "12", name: "Toyota 2JZ-GTE Engine", category: "Engine", price: 95000000, rating: 5.0, image: "🚀" },
  { id: "13", name: "Honda K20 Turbo Kit", category: "Engine", price: 45000000, rating: 4.9, image: "⚙️" },
  { id: "14", name: "Subaru EJ25 Performance Kit", category: "Engine", price: 38000000, rating: 4.7, image: "🔥" },
  { id: "15", name: "Ford EcoBoost Turbo Upgrade", category: "Turbo", price: 22000000, rating: 4.6, image: "💨" },

  { id: "16", name: "Brembo Big Brake Kit", category: "Brake", price: 20000000, rating: 4.9, image: "🛑" },
  { id: "17", name: "EBC Racing Brake Pads", category: "Brake", price: 1800000, rating: 4.6, image: "🧲" },
  { id: "18", name: "Wilwood Brake System", category: "Brake", price: 12500000, rating: 4.8, image: "⚙️" },
  { id: "19", name: "Project Mu Brake Fluid", category: "Brake", price: 800000, rating: 4.5, image: "💧" },
  { id: "20", name: "AP Racing Caliper Set", category: "Brake", price: 17000000, rating: 4.9, image: "🛠️" },

  { id: "21", name: "Volk Racing TE37 Wheels", category: "Wheel", price: 35000000, rating: 5.0, image: "🛞" },
  { id: "22", name: "Rays Gram Lights 57CR", category: "Wheel", price: 28000000, rating: 4.9, image: "🛞" },
  { id: "23", name: "Enkei RPF1 Wheels", category: "Wheel", price: 18000000, rating: 4.8, image: "🛞" },
  { id: "24", name: "Advan Racing GT Wheels", category: "Wheel", price: 32000000, rating: 4.9, image: "🛞" },
  { id: "25", name: "Work Meister S1 Wheels", category: "Wheel", price: 30000000, rating: 4.8, image: "🛞" },

  { id: "26", name: "Nitrous Oxide System NOS Kit", category: "Power", price: 15000000, rating: 4.7, image: "💥" },
  { id: "27", name: "ECU Hondata FlashPro", category: "Electronics", price: 8500000, rating: 4.8, image: "🧠" },
  { id: "28", name: "AEM Fuel Pump High Flow", category: "Fuel", price: 3200000, rating: 4.6, image: "⛽" },
  { id: "29", name: "K&N Performance Filter", category: "Intake", price: 900000, rating: 4.5, image: "🌬️" },
  { id: "30", name: "Turbo Oil Feed Line Kit", category: "Turbo", price: 1200000, rating: 4.6, image: "🛢️" },
];